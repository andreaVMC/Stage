come usarli:
avviare in sequenza i programmi chiamando il file sorgente: "inventario.txt":

#node estrai.js
#node eliminaspeciali.js
#node inserisciCommenti.js
#node aggiungispazi.js
#node prg.js
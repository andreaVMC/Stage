<?php
    $dbhost="localhost";
    $dbname="Festival_Comunali_Abbonamenti";
    $dbuser="root";
    $dbpassword="abcd";
?>
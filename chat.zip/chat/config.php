<?php
    $dbhost="localhost";
    $dbname="database_test";
    $dbuser="root";
    $dbpassword="abcd";
?>
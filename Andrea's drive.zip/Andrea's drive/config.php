<?php
    $dbhost="localhost";
    $dbname="AndreaVaccaro";
    $dbuser="root";
    $dbpassword="abcd";
?>